from django.shortcuts import render, HttpResponse, get_object_or_404
from django.http import Http404, HttpResponseRedirect
from django.urls import reverse
from django.views import generic
from .models import post


# Create your views here.
# def blog_list(request):
#     return render(request, "blog.html", {'my_blog':article})

# def blog_detail(request, slug):
#     return HttpResponse(slug)

class IndexView(generic.ListView):
    template_name = 'blog/index.html'
    model = post
    
    
class DetailView(generic.DetailView):
    model = post
    template_name = "blog/detail.html"
