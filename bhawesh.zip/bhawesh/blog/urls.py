from django.urls import path, include, reverse
from django.conf import settings
from . import views

app_name = 'blog'

urlpatterns = [
    path("", views.IndexView.as_view(), name="bloglist"),
    path("<slug:slug>", views.DetailView.as_view(), name="details"),
]