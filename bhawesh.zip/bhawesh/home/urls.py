from django.contrib import admin
from django.urls import path
from home import views
admin.site.site_header = "Dashboard"
admin.site.site_title = "Admin Panel"
admin.site.index_title = "Hey, Bhawesh"

urlpatterns = [
   path("", views.index, name="index"),
   path("projects/", views.projects, name="projects"),
   path("contact/", views.contact, name="contact"),
]
